<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accès non autorisé</title>
</head>
<body>
    <h2>Accès non autorisé</h2>
    <p>Désolé, vous n'avez pas les autorisations nécessaires pour accéder à cette page.</p>
    <p><a href="login.php">Connectez-vous</a></p>
</body>
</html>
